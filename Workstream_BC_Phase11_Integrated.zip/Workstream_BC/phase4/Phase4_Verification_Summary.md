# Phase 4 Verification Summary (v1.1)

All figures come from executing the package on 21 Oct 2026 (Python 3.13.16, pytest 9). `python generate_data.py`, `python validate_phase4.py` (exit code 0) and `python -m pytest test_phase4.py` were run. Nothing was entered by hand.

## Emissions (clean dataset, `emissions_summary.csv`)

| Stream | Activity | Factor | Result | Share of quantified total |
|---|---|---|---|---|
| Scope 1 diesel | 100,000 L | EF1 2.66155 kg CO2e/L | 266.155 tCO2e | 5.48% |
| **Scope 2 electricity** | 8,000 MWh | **EF2 550 kg CO2e/MWh** | **4,400.000 tCO2e** | **90.55%** |
| Scope 3 Cat. 4: Contractor A | 1,200,000 t-km | EF3 0.10163 kg CO2e/t-km | 121.956 tCO2e | 2.51% |
| Scope 3 Cat. 4: Contractor B | missing (12 × NULL) | EF3 | UNAVAILABLE | — |
| Scope 3 Cat. 4: Contractor C | 700,000 t-km | EF3 | 71.141 tCO2e | 1.46% |
| Scope 3 known subtotal (A + C) | 1,900,000 t-km | EF3 | 193.097 tCO2e | 3.97% |
| **Quantified total (indicative)** | | | **4,859.252 tCO2e** | 100% |

- **Electricity:** the 12 monthly records sum to 4,400.000 tCO2e, which equals 8,000 MWh × 550 ÷ 1,000. Scope 2 is about 16.5 times Scope 1.
- **Quantified total:** it is INCOMPLETE because Contractor B is unavailable, so it is not a complete inventory. A total can be shown now only because all three factors are CO2e. In v1.0 the CO2-only electricity factor prevented it.
- **Scope 1 and Scope 3:** diesel and freight record-level results are identical to v1.0. The v1.0 Scope 2 figure (4,913.600 tCO2) differs only because of the factor change. It is not an emissions reduction.

## Data-quality validation (actual execution)

- **Register integrity:** OK. EF2 passes the unit check (kg CO2e/MWh against MWh), the provenance fields, activity type, Scope 2 and the location-based method.
- **Clean data:** 60 records, **0 BLOCK**, 72 WARN, all expected:
  - 12 × DQ-01 (Contractor B);
  - 60 × DQ-13 (factor assumptions). The 12 electricity warnings give reference year 2024 vs activity year 2025 and `provisional_proxy`.
- **Test data:** 22/22 seeded cases PASS, covering 16/16 rules, with 18 BLOCK and 79 WARN findings. These counts are unchanged from v1.0.
- **pytest:** 35/35 passed.
- **Regression checks:**
  - No record references `FAC-ELE-GRID-01`, and 614.2 no longer appears in any active register or calculation.
  - Suppliers and provenance register are byte-identical to v1.0.
  - Activity quantities are unchanged.
- **Severity levels:** PASS, WARN and BLOCK are kept as before. Rule IDs DQ-01 to DQ-16 are unchanged.

## Consistency with Phase 3 (v1.1)

| Item | Phase 3 | Phase 4 | Match |
|---|---|---|---|
| Factor ID / value / unit | FAC-ELEC-SEC-01, 550 kg CO2e/MWh | same | ✓ |
| Source / reference year / geography | SEC 2024 Sustainability Report; 2024; Saudi Arabia | same | ✓ |
| Scope / boundary / method | 2; grid_generation; location_based | same | ✓ |
| Verification status | provisional_proxy; publication_year may be blank | same | ✓ |
| Calculation | MWh × 550 ÷ 1,000 | same; 8,000 MWh → 4,400 tCO2e | ✓ |
| Expected validator result | DQ-13 WARN on 12 electricity records, no BLOCK | same | ✓ |

**Note on rule IDs.** Rule IDs are numbered differently in the two phases. Phase 3 puts the factor boundary and activity-type check under DQ-14. Phase 4 has carried that check under DQ-13 since v1.0, where its DQ-14 to DQ-16 are the rules it added. This is the existing, documented Phase 4 deviation and was not renumbered.

## Unresolved methodological limitations

1. **The SEC value is unverified.** The official 2024 report was not reachable from the build environment. SEC's website lists the 2023 report, and the 2024 intensity was not found in a third-party copy. The published figure, its rounding, gas basis, MWh basis (generated vs delivered) and SEC-fleet vs national-grid coverage are all unconfirmed. EF2 stays `provisional_proxy`, and its publication year and report URL are blank or general.
2. **Year mismatch:** EF2 has reference year 2024 and is applied to 2025 activity.
3. **UK proxies:** EF1 and EF3 still need checking against the DESNZ workbook. EF3 is `unverified_placeholder` and has a direct (tank-to-wheel) boundary.
4. **Contractor B is missing,** so Scope 3 Category 4 and the quantified total are incomplete.
5. **Activity data are synthetic.**
