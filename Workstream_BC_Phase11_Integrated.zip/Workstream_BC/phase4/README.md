# Phase 4 — Synthetic Data, Emission Factor Library and Data-Quality Validation

Carbon Decision-Support Platform · fictional manufacturing facility, Riyadh Region · reporting year 2025 ·
operational control. **All activity data, suppliers and evidence documents are fictional/synthetic.**

## Contents

| File | Purpose |
|---|---|
| `data/activity_data_clean.csv` | 60 monthly records (5 streams × 12). 48 reported, 12 Contractor B quantities empty (NULL), `source_origin = synthetic` |
| `data/activity_data_test.csv` | Copy of the clean file with 22 seeded errors (19 modified rows + 3 appended) covering DQ-01…DQ-16 |
| `data/emission_factors.csv` | EF1 diesel, EF2 Saudi electricity (SEC 2024 provisional proxy, v1.1), EF3 road freight, with source, location, years, gas coverage, boundary, activity type, accounting scope/method, verification status |
| `data/suppliers.csv` | 5 fictional suppliers (utility, fuel supplier, Carriers A/B/C) |
| `data/provenance_register.csv` | 60 activity-evidence records + 2 labelled test-evidence records (activity provenance only) |
| `data/data_quality_test_cases.csv` | 22 seeded cases: input, expected result, actual result, PASS/FAIL (filled by validator) |
| `generate_data.py` | Deterministic generator for the files above |
| `validate_phase4.py` | DQ-01…DQ-16 validator + calculator |
| `test_phase4.py` | Automated acceptance tests (pytest) |
| `validation_report.csv` | Generated: every finding for both datasets, plus PASS rows |
| `emissions_results.csv` / `emissions_summary.csv` | Generated: record-level and stream-level results (clean data); summary includes the indicative quantified total and % shares |

## Run

```bash
pip install -r requirements.txt
python generate_data.py          # optional: rebuilds data/ (deterministic)
python validate_phase4.py        # exit code 0 = acceptance conditions met
python -m pytest -v test_phase4.py
```

## Rules

Emissions (t) = quantity × factor (kg per unit) ÷ 1,000. One factor per record. Results keep the factor's gas label;
totals are never summed across different gas labels. Since v1.1 all three factors are CO2e, so an indicative quantified
total (Scopes 1 + 2 + Contractors A and C) is reported, labelled INCOMPLETE because Contractor B is unavailable.
Missing activity is never replaced by zero. BLOCK = record not calculated and stream not published; WARN = calculated and flagged.

| ID | Rule | Severity |
|---|---|---|
| DQ-01 | Missing quantity | WARN (no calculation; stream INCOMPLETE) |
| DQ-02 | Duplicate activity_id | BLOCK |
| DQ-03 | Duplicate underlying activity | BLOCK exact / WARN probable |
| DQ-04 | Invalid date / outside 2025 | BLOCK |
| DQ-05 | Negative or non-numeric quantity | BLOCK |
| DQ-06 | Unit not approved / not expected | BLOCK (approved scale conversion = WARN) |
| DQ-07 | Missing/unknown supplier | BLOCK freight / WARN others |
| DQ-08 | Invalid or blank factor_id | BLOCK |
| DQ-09 | Factor unit ≠ activity unit | BLOCK |
| DQ-10 | Evidence blank / not found | WARN / BLOCK |
| DQ-11 | Outlier (1.5 × IQR of its series) | WARN |
| DQ-12 | Estimated or imputed | WARN |
| DQ-13 | Factor geography, year, gas, verification / boundary | WARN / BLOCK (incompatible boundary) |
| DQ-14 *(Phase 4)* | Status inconsistent with quantity | BLOCK |
| DQ-15 *(Phase 4)* | source_origin not `synthetic` | BLOCK |
| DQ-16 *(Phase 4)* | activity_type / scope / category / facility inconsistent | BLOCK |

## Expected warnings on clean data (not failures)

72 WARN, 0 BLOCK: 12 × DQ-01 (Contractor B missing) and 60 × DQ-13 (documented factor proxies:
UK geography for diesel and freight; electricity factor reference year 2024 and `provisional_proxy` status;
freight direct/TTW boundary; verification status of EF1/EF3).

## Electricity factor (v1.1)

`FAC-ELEC-SEC-01` = **550 kg CO2e/MWh** (approx. 0.55 tCO2e/MWh), Saudi Electricity Company (SEC) 2024 Sustainability
Report, reference year 2024, Saudi Arabia, Scope 2, `grid_generation` boundary, `location_based`,
`verification_status = provisional_proxy`. The published value, unit and reporting boundary could not be checked against
the primary report, so it is a provisional project assumption, not a verified national grid factor (Phase 3 Table 2a).
Electricity emissions = MWh × 550 ÷ 1,000 → 8,000 MWh = 4,400 tCO2e.
It replaces `FAC-ELE-GRID-01` (614.2 kg CO2/MWh, CO2 only, Climate Transparency 2022, data year 2021), which is no
longer referenced by any record; see `Phase4_Change_Log.md`. Not to be confused with Ember's lifecycle-inclusive
689.051 kgCO2e/MWh.

## Phase 3 deviations (documented)

* Added field `source_origin` to activity records and rules DQ-14…DQ-16.
* Added factor fields `source_location`, `gases_included`, `boundary_note`, `verification_note`; boundary value `vehicle_direct`
  and verification value `verified_secondary`.
* v1.1: factor register aligned with Phase 3 A-2 — added `activity_type`, `accounting_scope`, `accounting_method`;
  electricity boundary value `grid` renamed `grid_generation`; `provisional_proxy` status (publication_year may be blank
  while provisional). Factor activity_type mismatch reported under DQ-13 (BLOCK). Rule IDs DQ-01…DQ-16 unchanged.
* EF3 is a direct (tank-to-wheel) factor; Phase 3 preferred a life-cycle factor. Treated as WARN (nothing double counted; WTT excluded).
