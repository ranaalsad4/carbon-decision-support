"""Phase 4 - deterministic generator for the synthetic datasets.

Re-creates the five input CSV files (the sixth, data_quality_test_cases.csv,
is created here with blank actual-result columns and completed by
validate_phase4.py). All activity data is FICTIONAL / SYNTHETIC.

Usage:  python generate_data.py
"""
import csv
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"
FACILITY = "FAC-RUH-01"
MONTHS = [f"2025-{m:02d}" for m in range(1, 13)]

# ---------------------------------------------------------------- activity
# Monthly profiles (synthetic). Each list sums exactly to the fixed annual total.
PROFILES = {
    "ELE": [545, 540, 605, 665, 725, 785, 805, 805, 745, 665, 585, 530],          # 8,000 MWh
    "DSL": [7200, 6900, 7600, 8100, 8900, 9800, 10400, 10600, 9300, 8000, 7000, 6200],  # 100,000 L
    "FRT-A": [96500, 92000, 104000, 101500, 99000, 94500, 90000, 93500, 103000, 108500, 110000, 107500],  # 1,200,000 t-km
    "FRT-B": [None] * 12,                                                          # missing
    "FRT-C": [55000, 53500, 60500, 59000, 57500, 55500, 52000, 54000, 60000, 63000, 65500, 64500],  # 700,000 t-km
}

STREAMS = [
    # key, activity_type, scope, cat, unit, supplier, factor, source-id prefix, source_type
    ("ELE", "electricity_purchased", 2, "", "MWh", "SUP-UTIL-01", "FAC-ELEC-SEC-01", "INV-ELE", "utility_invoice"),
    ("DSL", "diesel_stationary", 1, "", "L", "SUP-FUEL-01", "FAC-DSL-COMB-01", "FINV-DSL", "fuel_invoice"),
    ("FRT-A", "freight_road_outbound", 3, 4, "tonne-km", "SUP-CARR-A", "FAC-FRT-ROAD-01", "STMT-A", "carrier_statement"),
    ("FRT-B", "freight_road_outbound", 3, 4, "tonne-km", "SUP-CARR-B", "FAC-FRT-ROAD-01", "REQ-B", "request_log"),
    ("FRT-C", "freight_road_outbound", 3, 4, "tonne-km", "SUP-CARR-C", "FAC-FRT-ROAD-01", "STMT-C", "carrier_statement"),
]

ACT_FIELDS = ["activity_id", "period", "facility_id", "activity_type", "scope", "scope3_category",
              "quantity", "unit", "supplier_id", "activity_source_id", "factor_id", "evidence_id",
              "data_status", "source_origin", "quality_flag"]
PROV_FIELDS = ["evidence_id", "source_type", "source_description", "source_reference",
               "source_url_or_path", "synthetic_status", "documentation_note"]

DESC = {
    "ELE": "FICTIONAL monthly grid electricity invoice (meter total), synthetic utility",
    "DSL": "FICTIONAL monthly diesel delivery invoice for stationary backup generators",
    "FRT-A": "FICTIONAL monthly tonne-km statement, Carrier A (synthetic)",
    "FRT-B": "FICTIONAL data-request log, Carrier B: no activity data received",
    "FRT-C": "FICTIONAL monthly tonne-km statement, Carrier C (synthetic)",
}
NOTE = {
    "ELE": "Quantity = invoiced MWh for the calendar month (synthetic).",
    "DSL": "Quantity = litres delivered and burned in facility generators in the month; stock change assumed zero (synthetic).",
    "FRT-A": "Carrier-reported tonne-km (shipment mass incl. packaging x actual road distance), summed for the month (synthetic).",
    "FRT-B": "No mass, distance or tonne-km received from carrier; quantity left empty (NULL), not zero. Estimate deferred.",
    "FRT-C": "Carrier-reported tonne-km (shipment mass incl. packaging x actual road distance), summed for the month (synthetic).",
}


def fmt(q):
    return "" if q is None else (str(int(q)) if float(q).is_integer() else str(q))


def build_clean():
    acts, prov, n = [], [], 0
    for key, atype, scope, cat, unit, sup, fac, src, stype in STREAMS:
        for i, period in enumerate(MONTHS):
            n += 1
            ym = period.replace("-", "")
            evd = f"EVD-{n:04d}"
            q = PROFILES[key][i]
            acts.append({
                "activity_id": f"ACT-{key}-{ym}", "period": period, "facility_id": FACILITY,
                "activity_type": atype, "scope": scope, "scope3_category": cat, "quantity": fmt(q),
                "unit": unit, "supplier_id": sup, "activity_source_id": f"{src}-{period}",
                "factor_id": fac, "evidence_id": evd,
                "data_status": "missing" if q is None else "reported",
                "source_origin": "synthetic", "quality_flag": "NOT_RUN"})
            prov.append({
                "evidence_id": evd, "source_type": stype, "source_description": DESC[key],
                "source_reference": f"{src}-{period}",
                "source_url_or_path": f"data/evidence/synthetic/{src}-{period}.pdf (fictional, not supplied)",
                "synthetic_status": "synthetic_clean", "documentation_note": NOTE[key]})
    return acts, prov


# ------------------------------------------------------------- test seeds
# Each seed: (test_case_id, rule_id, expected_severity, activity_id, description, change)
# change = dict of field overrides for an existing row, or ("APPEND", base_id, overrides).
SEEDS = [
    ("TC-01", "DQ-01", "WARN", "ACT-FRT-C-202505", "Contractor C May quantity removed (status consistently 'missing')",
     {"quantity": "", "data_status": "missing"}),
    ("TC-02", "DQ-02", "BLOCK", "ACT-DSL-202502", "Second record re-uses activity_id ACT-DSL-202502 (supplementary invoice)",
     ("APPEND", "ACT-DSL-202502", {"activity_source_id": "FINV-DSL-2025-02-SUPP", "quantity": "7000",
                                   "evidence_id": "EVD-T002"})),
    ("TC-03", "DQ-03", "BLOCK", "ACT-FRT-A-202506-DUP", "Exact duplicate of Carrier A June statement under a new ID",
     ("APPEND", "ACT-FRT-A-202506", {"activity_id": "ACT-FRT-A-202506-DUP"})),
    ("TC-04", "DQ-03", "WARN", "ACT-FRT-C-202507-R", "Re-sent Carrier C July statement: same quantity and evidence, new source number",
     ("APPEND", "ACT-FRT-C-202507", {"activity_id": "ACT-FRT-C-202507-R",
                                     "activity_source_id": "STMT-C-2025-07-RESENT"})),
    ("TC-05", "DQ-04", "BLOCK", "ACT-ELE-202508", "Period '2025-13' is not a valid month", {"period": "2025-13"}),
    ("TC-06", "DQ-04", "BLOCK", "ACT-DSL-202511", "Period '2024-11' is outside the 2025 reporting year", {"period": "2024-11"}),
    ("TC-07", "DQ-05", "BLOCK", "ACT-DSL-202503", "Negative diesel quantity", {"quantity": "-7600"}),
    ("TC-08", "DQ-06", "BLOCK", "ACT-DSL-202504", "Diesel unit 'gal' is not an approved unit", {"unit": "gal"}),
    ("TC-09", "DQ-06", "WARN", "ACT-ELE-202502", "Electricity reported in kWh: approved scale conversion to MWh, logged",
     {"unit": "kWh", "quantity": "540000"}),
    ("TC-10", "DQ-07", "BLOCK", "ACT-FRT-C-202509", "Freight record without supplier_id", {"supplier_id": ""}),
    ("TC-11", "DQ-07", "WARN", "ACT-ELE-202509", "Electricity supplier_id not in supplier register", {"supplier_id": "SUP-UTIL-99"}),
    ("TC-12", "DQ-08", "BLOCK", "ACT-FRT-A-202510", "factor_id not in factor register", {"factor_id": "FAC-FRT-ROAD-99"}),
    ("TC-13", "DQ-09", "BLOCK", "ACT-FRT-A-202511", "Freight record assigned electricity factor (kg CO2e/MWh vs tonne-km)",
     {"factor_id": "FAC-ELEC-SEC-01"}),
    ("TC-14", "DQ-10", "BLOCK", "ACT-DSL-202506", "evidence_id not found in provenance register", {"evidence_id": "EVD-9999"}),
    ("TC-15", "DQ-10", "WARN", "ACT-DSL-202507", "evidence_id left blank", {"evidence_id": ""}),
    ("TC-16", "DQ-11", "WARN", "ACT-ELE-202510", "Electricity October set to 2,660 MWh (about 4x normal)", {"quantity": "2660"}),
    ("TC-17", "DQ-12", "WARN", "ACT-FRT-C-202503", "Carrier C March marked as estimated", {"data_status": "estimated",
                                                                                         "evidence_id": "EVD-T017"}),
    ("TC-18", "DQ-13", "BLOCK", "ACT-DSL-202508", "Stationary diesel assigned road-freight vehicle factor (boundary incompatible)",
     {"factor_id": "FAC-FRT-ROAD-01"}),
    ("TC-19", "DQ-14", "BLOCK", "ACT-FRT-B-202504", "Contractor B April: quantity empty but data_status = 'reported'",
     {"data_status": "reported"}),
    ("TC-20", "DQ-14", "BLOCK", "ACT-ELE-202512", "Electricity December: quantity present but data_status = 'missing'",
     {"data_status": "missing"}),
    ("TC-21", "DQ-15", "BLOCK", "ACT-FRT-A-202512", "source_origin = 'real_company' in a synthetic-only prototype",
     {"source_origin": "real_company"}),
    ("TC-22", "DQ-16", "BLOCK", "ACT-FRT-C-202512", "Freight record classified as scope 1", {"scope": "1"}),
]
# Other rules that a seed legitimately also triggers (documented, not failures)
ALSO = {"TC-13": "DQ-13 BLOCK (grid_generation boundary on freight)", "TC-18": "DQ-09 BLOCK (tonne-km factor vs L)",
        "TC-19": "DQ-01 WARN (empty quantity)"}

TEST_EVIDENCE = [
    {"evidence_id": "EVD-T002", "source_type": "fuel_invoice",
     "source_description": "FICTIONAL TEST EVIDENCE: supplementary diesel invoice re-using an existing activity_id",
     "source_reference": "FINV-DSL-2025-02-SUPP", "source_url_or_path": "", "synthetic_status": "synthetic_corrupted",
     "documentation_note": "Seeded for TC-02 (DQ-02). Not part of the clean dataset."},
    {"evidence_id": "EVD-T017", "source_type": "other",
     "source_description": "FICTIONAL TEST EVIDENCE: estimate note for Carrier C March",
     "source_reference": "EST-C-2025-03", "source_url_or_path": "", "synthetic_status": "synthetic_estimated",
     "documentation_note": "Seeded for TC-17 (DQ-12). Method: illustrative only. Not part of the clean dataset."},
]


def build_test(clean):
    rows = [dict(r) for r in clean]
    index = {r["activity_id"]: r for r in rows}
    cases = []
    for tc, rule, sev, aid, desc, change in SEEDS:
        if isinstance(change, tuple):
            _, base, over = change
            new = dict(index[base]); new.update(over)
            rows.append(new)
            original, corrupted = "(no record)", "; ".join(f"{k}={v}" for k, v in over.items())
            corrupted = f"appended copy of {base}: {corrupted}"
        else:
            r = index[aid]
            original = "; ".join(f"{k}={r[k] if r[k] != '' else '(empty)'}" for k in change)
            corrupted = "; ".join(f"{k}={v if v != '' else '(empty)'}" for k, v in change.items())
            r.update(change)
        cases.append({"test_case_id": tc, "rule_id": rule, "activity_id": aid, "description": desc,
                      "original_value": original, "corrupted_value": corrupted,
                      "expected_outcome": sev, "expected_flag": rule,
                      "also_expected": ALSO.get(tc, ""), "actual_outcome": "", "actual_flags": "",
                      "test_result": ""})
    return rows, cases


# ---------------------------------------------------------------- registers
FACTORS = [
    {"factor_id": "FAC-DSL-COMB-01", "factor_name": "Diesel (100% mineral diesel), stationary combustion",
     "factor_value": "2.66155", "factor_unit": "kg CO2e/L",
     "source_organization": "UK Department for Energy Security and Net Zero (DESNZ)",
     "source_title": "Greenhouse gas reporting: conversion factors 2025 (full set)",
     "source_url": "https://www.gov.uk/government/publications/greenhouse-gas-reporting-conversion-factors-2025",
     "source_location": "Full-set workbook > 'Fuels' sheet > row 76 > Diesel (100% mineral diesel) > litres > kg CO2e (total)",
     "publication_year": "2025", "applicable_year": "2025", "geography": "United Kingdom (proxy for Saudi Arabia)",
     "gas_coverage": "CO2e", "gases_included": "CO2, CH4, N2O (AR5 GWP100)", "boundary": "combustion",
     "boundary_note": "Direct combustion only; well-to-tank (upstream, Scope 3 Cat. 3) excluded",
     "factor_version": "DESNZ 2025 v1.0 (published 10 Jun 2025)",
     "uncertainty_note": "UK fuel specification used as proxy for Saudi diesel; 100% mineral diesel (no biofuel blend) chosen as closer to Saudi supply.",
     "verification_status": "verified_secondary",
     "verification_note": "Value 2.66155 kg CO2e/L matches the DESNZ 2025 factor as mirrored by the Climatiq database (checked 2026-10-20). Primary workbook row 76 not opened from the build environment; confirm before Phase 5.",
     "conversion_note": "",
     "activity_type": "diesel_stationary", "accounting_scope": "1", "accounting_method": "not_applicable"},
    # Electricity factor revised in v1.1 (Phase 3 Table 2a). Supersedes FAC-ELE-GRID-01
    # (614.2 kg CO2/MWh, Climate Transparency 2022, data year 2021, CO2 only) - see Phase4_Change_Log.md.
    {"factor_id": "FAC-ELEC-SEC-01", "factor_name": "Grid electricity, SEC-reported emissions intensity (provisional Scope 2 proxy)",
     "factor_value": "550", "factor_unit": "kg CO2e/MWh",
     "source_organization": "Saudi Electricity Company (SEC)",
     "source_title": "SEC 2024 Sustainability Report",
     "source_url": "https://www.se.com.sa",
     "source_location": "Not confirmed: report page/table and report-specific URL not located (official report not accessible from the build environment; checked 2026-10-21). Project input: approx. 0.55 tCO2e/MWh.",
     "publication_year": "", "applicable_year": "2024", "geography": "Saudi Arabia (SEC-reported system)",
     "gas_coverage": "CO2e", "gases_included": "CO2e as stated for the project value; gas breakdown and GWP basis not confirmed",
     "boundary": "grid_generation",
     "boundary_note": "Generation-based intensity used as provisional location-based Scope 2 proxy; MWh basis (generated vs delivered), T&D treatment and SEC-fleet vs national-grid coverage not confirmed; upstream fuel (Scope 3 Cat. 3) not included.",
     "factor_version": "SEC-SR-2024 v1 (provisional)",
     "uncertainty_note": "Approximate value (0.55 tCO2e/MWh); exact published figure, rounding and basis not confirmed against the primary report. Applicability depends on the facility's supply arrangements and SEC's reporting coverage. Not a verified national Scope 2 grid factor.",
     "verification_status": "provisional_proxy",
     "verification_note": "Value, unit and reporting boundary not verified: official SEC 2024 report not reachable from the build environment and the intensity not located in a third-party copy (checked 2026-10-21). Retained as a provisional project assumption (Phase 3 Table 2a). Not Ember's lifecycle-inclusive 689.051 kgCO2e/MWh.",
     "conversion_note": "0.55 tCO2e/MWh x 1,000 = 550 kg CO2e/MWh (t->kg scale conversion only).",
     "activity_type": "electricity_purchased", "accounting_scope": "2", "accounting_method": "location_based"},
    {"factor_id": "FAC-FRT-ROAD-01", "factor_name": "HGV (all diesel), all HGVs, average laden - freighting goods",
     "factor_value": "0.10163", "factor_unit": "kg CO2e/tonne-km",
     "source_organization": "UK Department for Energy Security and Net Zero (DESNZ)",
     "source_title": "Greenhouse gas reporting: conversion factors 2025 (full set)",
     "source_url": "https://www.gov.uk/government/publications/greenhouse-gas-reporting-conversion-factors-2025",
     "source_location": "Full-set workbook > 'Freighting goods' sheet > row 64 > HGV (all diesel) > All HGVs > Average laden > tonne.km > kg CO2e",
     "publication_year": "2025", "applicable_year": "2025", "geography": "United Kingdom (proxy for Saudi road freight)",
     "gas_coverage": "CO2e", "gases_included": "CO2, CH4, N2O (AR5 GWP100)", "boundary": "vehicle_direct",
     "boundary_note": "Direct (tank-to-wheel) vehicle emissions; well-to-tank excluded (DESNZ reports WTT separately). Phase 3 preferred a life-cycle factor: documented deviation.",
     "factor_version": "DESNZ 2025 v1.0 (published 10 Jun 2025)",
     "uncertainty_note": "UK fleet average laden factor; Saudi load factors, truck mix and empty running may differ; not carrier specific.",
     "verification_status": "unverified_placeholder",
     "verification_note": "Prototype value selected by the project team. Primary workbook row 64 could not be opened and no independent copy of 0.10163 was found (checked 2026-10-20). Confirm before Phase 5.",
     "conversion_note": "Source spelling 'tonne.km' normalised to 'tonne-km'.",
     "activity_type": "freight_road_outbound", "accounting_scope": "3", "accounting_method": "not_applicable"},
]
SUPPLIERS = [
    {"supplier_id": "SUP-UTIL-01", "supplier_name": "Najd Grid Power Co. (fictional, synthetic)", "supplier_type": "electricity_utility",
     "transport_mode": "not_applicable", "service_description": "Grid electricity supplied to the facility meter; company pays per invoice."},
    {"supplier_id": "SUP-FUEL-01", "supplier_name": "Al-Wadi Fuels Trading (fictional, synthetic)", "supplier_type": "fuel_supplier",
     "transport_mode": "not_applicable", "service_description": "Delivers diesel to facility tanks for company-operated stationary backup generators; company pays."},
    {"supplier_id": "SUP-CARR-A", "supplier_name": "Carrier A Logistics (fictional, synthetic)", "supplier_type": "freight_carrier",
     "transport_mode": "road", "service_description": "Outbound road freight; carrier-owned and carrier-operated trucks; reporting company pays (Scope 3 Cat. 4)."},
    {"supplier_id": "SUP-CARR-B", "supplier_name": "Carrier B Transport (fictional, synthetic)", "supplier_type": "freight_carrier",
     "transport_mode": "road", "service_description": "Outbound road freight; carrier-owned and carrier-operated trucks; reporting company pays (Scope 3 Cat. 4). No activity data supplied."},
    {"supplier_id": "SUP-CARR-C", "supplier_name": "Carrier C Haulage (fictional, synthetic)", "supplier_type": "freight_carrier",
     "transport_mode": "road", "service_description": "Outbound road freight; carrier-owned and carrier-operated trucks; reporting company pays (Scope 3 Cat. 4)."},
]


def write(name, fields, rows):
    DATA.mkdir(exist_ok=True)
    with open(DATA / name, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(rows)


def main():
    clean, prov = build_clean()
    test, cases = build_test(clean)
    write("activity_data_clean.csv", ACT_FIELDS, clean)
    write("activity_data_test.csv", ACT_FIELDS, test)
    write("emission_factors.csv", list(FACTORS[0].keys()), FACTORS)
    write("suppliers.csv", list(SUPPLIERS[0].keys()), SUPPLIERS)
    write("provenance_register.csv", PROV_FIELDS, prov + TEST_EVIDENCE)
    write("data_quality_test_cases.csv", list(cases[0].keys()), cases)
    print(f"clean={len(clean)} test={len(test)} evidence={len(prov) + len(TEST_EVIDENCE)} cases={len(cases)}")


if __name__ == "__main__":
    main()
