"""Phase 4 acceptance tests.   Run:  python -m pytest -v test_phase4.py"""
import csv
from collections import Counter
from math import isclose

import pytest

import validate_phase4 as v

FACTORS, SUPPLIERS, EVIDENCE = v.load_registers()
CLEAN = v.read("activity_data_clean.csv")
TEST = v.read("activity_data_test.csv")


@pytest.fixture(scope="module")
def clean_run():
    findings, state = v.validate(CLEAN, FACTORS, SUPPLIERS, EVIDENCE)
    results = v.calculate(CLEAN, state, FACTORS)
    return findings, results, v.summarise(results)


@pytest.fixture(scope="module")
def test_run():
    findings, _ = v.validate(TEST, FACTORS, SUPPLIERS, EVIDENCE)
    return findings


def total(atype, supplier=None):
    return sum(float(r["quantity"]) for r in CLEAN if r["activity_type"] == atype and r["quantity"]
               and (supplier is None or r["supplier_id"] == supplier))


# ---------- dataset structure
def test_exactly_60_clean_records_and_12_months_per_stream():
    assert len(CLEAN) == 60
    per_stream = Counter((r["activity_type"], r["supplier_id"]) for r in CLEAN)
    assert len(per_stream) == 5 and set(per_stream.values()) == {12}
    for s in per_stream:
        months = {r["period"] for r in CLEAN if (r["activity_type"], r["supplier_id"]) == s}
        assert months == {f"2025-{m:02d}" for m in range(1, 13)}


def test_annual_totals():
    assert total("electricity_purchased") == 8_000
    assert total("diesel_stationary") == 100_000
    assert total("freight_road_outbound", "SUP-CARR-A") == 1_200_000
    assert total("freight_road_outbound", "SUP-CARR-C") == 700_000


def test_contractor_b_has_12_null_quantities_not_zero():
    b = [r for r in CLEAN if r["supplier_id"] == "SUP-CARR-B"]
    assert len(b) == 12
    assert all(r["quantity"] == "" and r["data_status"] == "missing" for r in b)
    assert not any(r["quantity"].strip() in {"0", "0.0"} for r in CLEAN)


def test_clean_counts_48_reported_and_synthetic_origin():
    assert sum(r["data_status"] == "reported" for r in CLEAN) == 48
    assert {r["source_origin"] for r in CLEAN} == {"synthetic"}


# ---------- reference integrity
def test_reference_integrity():
    for r in CLEAN:
        assert r["factor_id"] in FACTORS
        assert r["supplier_id"] in SUPPLIERS
        assert r["evidence_id"] in EVIDENCE
    assert len({r["evidence_id"] for r in CLEAN}) == 60
    assert v.check_registers(FACTORS, SUPPLIERS, EVIDENCE) == []


def test_provenance_separate_from_factors():
    prov_fields = set(next(iter(EVIDENCE.values())).keys())
    assert "factor_id" not in prov_fields
    assert all(not e["evidence_id"].startswith("FAC-") for e in EVIDENCE.values())


def test_factor_register_values_and_labels():
    assert FACTORS["FAC-DSL-COMB-01"]["factor_value"] == "2.66155"
    assert FACTORS["FAC-ELEC-SEC-01"]["factor_value"] == "550"
    assert FACTORS["FAC-FRT-ROAD-01"]["factor_value"] == "0.10163"
    assert len(FACTORS) == 3


def test_electricity_factor_matches_phase3_record():
    """Phase 3 Table 2a: SEC 2024 provisional location-based Scope 2 proxy."""
    f = FACTORS["FAC-ELEC-SEC-01"]
    assert f["factor_unit"] == "kg CO2e/MWh" and f["gas_coverage"] == "CO2e"
    assert f["source_organization"] == "Saudi Electricity Company (SEC)"
    assert f["source_title"] == "SEC 2024 Sustainability Report"
    assert f["applicable_year"] == "2024" and f["geography"].startswith("Saudi Arabia")
    assert f["activity_type"] == "electricity_purchased" and f["accounting_scope"] == "2"
    assert f["boundary"] == "grid_generation" and f["accounting_method"] == "location_based"
    assert f["verification_status"] == "provisional_proxy" and f["uncertainty_note"]


def test_previous_electricity_factor_not_used():
    assert "FAC-ELE-GRID-01" not in FACTORS
    assert all(r["factor_id"] != "FAC-ELE-GRID-01" for r in CLEAN + TEST)
    assert all(f["factor_value"] != "614.2" for f in FACTORS.values())


# ---------- clean-data validation
def test_no_block_findings_on_clean_data(clean_run):
    findings, _, _ = clean_run
    assert [f for f in findings if f["severity"] == "BLOCK"] == []


def test_clean_warnings_are_all_expected(clean_run):
    findings, _, _ = clean_run
    warns = [f for f in findings if f["severity"] == "WARN"]
    assert warns and all(f["expected_warning"] == "yes" for f in warns)
    assert {f["rule_id"] for f in warns} == {"DQ-01", "DQ-13"}
    assert sum(f["rule_id"] == "DQ-01" for f in warns) == 12


# ---------- calculations
def test_emissions_results(clean_run):
    _, results, streams = clean_run
    s = {(k[0], k[2]): val for k, val in streams.items()}
    assert isclose(s[("1", "SUP-FUEL-01")]["emissions"], 266.155, abs_tol=1e-6)
    assert isclose(s[("2", "SUP-UTIL-01")]["emissions"], 8000 * 550 / 1000, abs_tol=1e-6)   # 4,400 tCO2e
    assert isclose(s[("3", "SUP-CARR-A")]["emissions"], 121.956, abs_tol=1e-6)
    assert isclose(s[("3", "SUP-CARR-C")]["emissions"], 71.141, abs_tol=1e-6)
    assert isclose(s[("3", "SUP-CARR-A")]["emissions"] + s[("3", "SUP-CARR-C")]["emissions"], 193.097, abs_tol=1e-6)


def test_contractor_b_unavailable_not_zero(clean_run):
    _, results, streams = clean_run
    b = streams[("3", "freight_road_outbound", "SUP-CARR-B")]
    assert b["emissions"] is None and b["status"] == "INCOMPLETE"
    assert all(r["emissions_t"] == "" and r["calc_status"] == "NOT_CALCULATED_MISSING"
               for r in results if r["supplier_id"] == "SUP-CARR-B")


def test_gas_labels_preserved(clean_run):
    _, results, _ = clean_run
    units = {r["activity_type"]: r["emissions_unit"] for r in results}
    assert units == {"electricity_purchased": "tCO2e", "diesel_stationary": "tCO2e", "freight_road_outbound": "tCO2e"}


def test_quantified_total_and_shares(clean_run):
    _, _, streams = clean_run
    total, units = v.quantified_total(streams)
    assert units == {"tCO2e"}
    assert isclose(total, 266.155 + 4400 + 121.956 + 71.141, abs_tol=1e-6)
    shares = [s["emissions"] / total for s in streams.values() if s["emissions"] is not None]
    assert isclose(sum(shares), 1.0, abs_tol=1e-9)


def test_one_factor_per_record_no_double_counting(clean_run):
    _, results, _ = clean_run
    assert len({r["activity_id"] for r in results}) == len(results) == 60
    assert all(FACTORS[r["factor_id"]]["boundary"] != "upstream_only" for r in CLEAN)


# ---------- seeded errors
def test_clean_file_untouched_by_test_file():
    clean_ids = {r["activity_id"] for r in CLEAN}
    assert clean_ids <= {r["activity_id"] for r in TEST} and len(TEST) > len(CLEAN)


def test_all_seeded_cases_detected(test_run):
    cases = list(csv.DictReader(open(v.DATA / "data_quality_test_cases.csv", encoding="utf-8")))
    for c in cases:
        hits = {f["severity"] for f in test_run if f["activity_id"] == c["activity_id"] and f["rule_id"] == c["rule_id"]}
        assert c["expected_outcome"] in hits, f"{c['test_case_id']} {c['rule_id']} not detected"
    assert {c["rule_id"] for c in cases} == {f"DQ-{i:02d}" for i in range(1, 17)}


@pytest.mark.parametrize("rule", [f"DQ-{i:02d}" for i in range(1, 17)])
def test_each_rule_fires_on_test_data(test_run, rule):
    assert any(f["rule_id"] == rule for f in test_run)


def test_blocked_records_are_not_calculated():
    findings, state = v.validate(TEST, FACTORS, SUPPLIERS, EVIDENCE)
    results = v.calculate(TEST, state, FACTORS)
    for r in results:
        if r["calc_status"] == "BLOCKED":
            assert r["emissions_t"] == ""
