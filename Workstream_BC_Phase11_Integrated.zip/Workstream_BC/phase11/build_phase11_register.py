"""Builds phase11/Phase11_Supplier_Decision_Assumptions_Register.xlsx (the editable Phase 11 source).

    python phase11/build_phase11_register.py      # then recalculate formulas in Excel or LibreOffice

Every row carries a data class:
  Existing synthetic baseline | New synthetic assumption | User-entered | Calculated output |
  Missing data | Project-designed rule | Reference
All supplier, cost, reliability and emission-factor values are SYNTHETIC demonstration values.
Contractor A's inventory baseline (121.956 tCO2e) is never edited here: Phase 11 reads it from the
Workstream B engine, and the lane values below are a separate decision dataset.
"""
from pathlib import Path

from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

OUT = Path(__file__).resolve().parent / "Phase11_Supplier_Decision_Assumptions_Register.xlsx"
NAVY, WHITE = "1F3A5F", "FFFFFF"
FONT = "Arial"
CLASS_FILL = {
    "Existing synthetic baseline": "DDEBF7", "New synthetic assumption": "FFF2CC", "User-entered": "FFFF00",
    "Calculated output": "E2EFDA", "Missing data": "F8CBAD", "Project-designed rule": "EDE7F6", "Reference": "F2F2F2",
}
CLASSES = list(CLASS_FILL)
thin = Side(style="thin", color="BFBFBF")
BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)


def header(ws, row, cols, widths=None):
    for j, h in enumerate(cols, start=1):
        c = ws.cell(row=row, column=j, value=h)
        c.font = Font(name=FONT, bold=True, color=WHITE, size=10)
        c.fill = PatternFill("solid", fgColor=NAVY)
        c.alignment = Alignment(wrap_text=True, vertical="center")
        c.border = BORDER
    if widths:
        for j, w in enumerate(widths, start=1):
            ws.column_dimensions[get_column_letter(j)].width = w
    ws.freeze_panes = ws.cell(row=row + 1, column=1)


def put_rows(ws, start, rows, class_col=None, input_cols=()):
    for i, r in enumerate(rows):
        for j, v in enumerate(r, start=1):
            c = ws.cell(row=start + i, column=j, value=v)
            is_formula = isinstance(v, str) and v.startswith("=")
            c.font = Font(name=FONT, size=10, color=("000000" if is_formula else "0000FF" if j in input_cols else "000000"))
            c.alignment = Alignment(wrap_text=True, vertical="top")
            c.border = BORDER
        if class_col:
            cls = r[class_col - 1]
            if cls in CLASS_FILL:
                ws.cell(row=start + i, column=class_col).fill = PatternFill("solid", fgColor=CLASS_FILL[cls])
    return start + len(rows)


def title(ws, text, sub=None):
    ws["A1"] = text
    ws["A1"].font = Font(name=FONT, bold=True, size=13, color=NAVY)
    if sub:
        ws["A2"] = sub
        ws["A2"].font = Font(name=FONT, italic=True, size=9, color="595959")


def dropdown(ws, rng, options, prompt=None):
    dv = DataValidation(type="list", formula1='"' + ",".join(options) + '"', allow_blank=True)
    if prompt:
        dv.prompt, dv.showInputMessage = prompt, True
    ws.add_data_validation(dv)
    dv.add(rng)


def decimal_rule(ws, rng, lo, hi, msg):
    dv = DataValidation(type="decimal", operator="between", formula1=str(lo), formula2=str(hi), allow_blank=True)
    dv.error, dv.showErrorMessage = msg, True
    ws.add_data_validation(dv)
    dv.add(rng)


wb = Workbook()

# 1 README --------------------------------------------------------------------------------
ws = wb.active
ws.title = "README"
title(ws, "PHASE 11 | Supplier Decision, Alternative Selection & Engagement — Assumptions Register",
      "Carbon Decision-Support Assistant · fictional facility, Riyadh Region · reporting year 2025 · ALL VALUES SYNTHETIC")
lines = [
    ("Purpose", "Editable source of every Phase 11 input: supplier profiles, freight lanes, supplier-specific factors, costs, "
                "screening evidence, maturity, matrix rules, scoring weights, uncertainty ranges, action templates and monitoring indicators."),
    ("Status", "Synthetic demonstration data. Supplier names, costs, reliability, emission factors and tender responses are "
               "fictional. Nothing here is a verified supplier disclosure, a quotation, an audit finding or a contract decision."),
    ("Baseline", "The historical inventory (Contractor A 121.956, Contractor C 71.141 tCO2e; Contractor B UNAVAILABLE) is read "
                 "by the application from Workstream B. It is NOT stored or editable here, so supplier scenarios cannot overwrite it."),
    ("Methodology", "Procurement cycle and impact/maturity segmentation follow the UN Global Compact Sustainable Procurement "
                    "Implementation Framework; Scope 3 Category 4 accounting follows the GHG Protocol. All numeric thresholds, "
                    "weights, scoring rules and decision rules are PROJECT-DESIGNED assumptions, not UN or GHG Protocol rules."),
    ("How to edit", "Change blue input cells. Keep IDs unique. Use the dropdowns. Leave a cell blank when the value is unknown: "
                    "blanks are treated as MISSING (never as zero). Black cells are formulas (calculated outputs)."),
    ("Loading", "The app loads this file at start-up (phase11/...xlsx) or an edited copy uploaded in the 'Supplier Decision & "
                "Engagement' tab. Calculated cells are recomputed by the Python engines; workbook formulas are cross-checks."),
]
r = put_rows(ws, 4, [list(x) for x in lines])
ws.column_dimensions["A"].width, ws.column_dimensions["B"].width = 18, 120
ws.cell(row=r + 1, column=1, value="Data classes (colour of the data_class cell)").font = Font(name=FONT, bold=True)
for k, (cls, fill) in enumerate(CLASS_FILL.items()):
    c = ws.cell(row=r + 2 + k, column=1, value=cls)
    c.fill = PatternFill("solid", fgColor=fill); c.font = Font(name=FONT, size=10)
desc = {"Existing synthetic baseline": "From Phases 4-7 inventory (synthetic)", "New synthetic assumption": "Introduced in Phase 11 (synthetic)",
        "User-entered": "Value supplied by a user of the register", "Calculated output": "Formula or engine result",
        "Missing data": "Value unknown - treated as missing, never zero", "Project-designed rule": "Threshold, weight or rule chosen by the project",
        "Reference": "External source citation"}
for k, cls in enumerate(CLASS_FILL):
    ws.cell(row=r + 2 + k, column=2, value=desc[cls]).font = Font(name=FONT, size=10)
ws.cell(row=r + 10, column=1, value="Sheets").font = Font(name=FONT, bold=True)
sheets = ["Supplier Profiles", "Freight Activity", "Emission Factors", "Service Equivalence", "Financial Inputs",
          "Screening Evidence", "Supplier Maturity", "Engagement Matrix Rules", "Scoring Weights", "Uncertainty Assumptions",
          "Engagement Action Plans", "Monitoring Indicators", "Source Register", "Validation Cases"]
for k, s in enumerate(sheets):
    ws.cell(row=r + 11 + k, column=1, value=k + 2).font = Font(name=FONT, size=10)
    ws.cell(row=r + 11 + k, column=2, value=s).font = Font(name=FONT, size=10)

# 2 Supplier Profiles -----------------------------------------------------------------------
ws = wb.create_sheet("Supplier Profiles")
title(ws, "Supplier profiles", "One row per supplier. relationship: Existing supplier | Hypothetical alternative | User-added.")
cols = ["supplier_id", "supplier_name", "relationship", "inventory_supplier_id", "transport_mode", "fuel_technology",
        "service_geography", "service_materiality", "data_class", "notes"]
header(ws, 4, cols, [13, 34, 22, 18, 13, 34, 30, 16, 24, 60])
rows = [
    ["SUP-CARR-A", "Carrier A Logistics (fictional)", "Existing supplier", "SUP-CARR-A", "road", "Diesel HGV, mixed fleet",
     "Riyadh - Dammam; Riyadh region", "Critical", "Existing synthetic baseline",
     "Inventory (Workstream B): 1,200,000 t-km, 121.956 tCO2e with proxy factor FAC-FRT-ROAD-01."],
    ["SUP-CARR-B", "Carrier B Transport (fictional)", "Existing supplier", "SUP-CARR-B", "road", None, None, "Standard",
     "Missing data", "No mass, distance or tonne-km received for any month of 2025; emissions UNAVAILABLE (not zero)."],
    ["SUP-CARR-C", "Carrier C Haulage (fictional)", "Existing supplier", "SUP-CARR-C", "road", "Diesel HGV with telematics",
     "Riyadh - Jeddah", "Standard", "Existing synthetic baseline",
     "Inventory (Workstream B): 700,000 t-km, 71.141 tCO2e with proxy factor FAC-FRT-ROAD-01."],
    ["ALT-D", "Alternative Carrier D (hypothetical)", "Hypothetical alternative", None, "road",
     "Euro VI diesel HGV, higher load factor (claimed)", "Riyadh - Dammam", "Standard", "New synthetic assumption",
     "Synthetic tender response for lane L1. Not a real company or quotation."],
    ["ALT-E", "Alternative Carrier E (hypothetical)", "Hypothetical alternative", None, "road",
     "Diesel HGV (claimed low-emission)", "Riyadh - Dammam", "Standard", "New synthetic assumption",
     "Synthetic tender response used to demonstrate a failed safety/legal gate."],
]
put_rows(ws, 5, rows, class_col=9, input_cols=range(1, 11))
dropdown(ws, "C5:C60", ["Existing supplier", "Hypothetical alternative", "User-added"])
dropdown(ws, "E5:E60", ["road", "rail", "sea", "air", "multimodal"])
dropdown(ws, "H5:H60", ["Critical", "Standard", "Minor"])
dropdown(ws, "I5:I60", CLASSES)

# 4 Service Equivalence (lanes) ------------------------------------------------------------
ws_l = wb.create_sheet("Service Equivalence")
# (sheet order fixed below)
title(ws_l, "Service requirements (functional unit = tonne-km for the same lane and service requirements)",
      "Offers are compared only with the requirements of the lane they bid for.")
cols = ["lane_id", "lane_name", "origin", "destination", "transport_mode", "cargo_type", "required_capacity_t_per_year",
        "required_on_time_pct", "reporting_period", "incumbent_offer_id", "data_class", "notes"]
header(ws_l, 4, cols, [9, 38, 18, 20, 13, 26, 16, 14, 12, 16, 24, 50])
rows = [
    ["L1", "Outbound palletised goods to Dammam", "Riyadh facility", "Dammam port area", "road", "Palletised general goods",
     2500, 95, "2025", "OF-A-L1", "New synthetic assumption", "Lane split of Contractor A's inventory activity (synthetic)."],
    ["L2", "Outbound palletised goods to Jeddah", "Riyadh facility", "Jeddah", "road", "Palletised general goods", 700, 90,
     "2025", "OF-C-L2", "New synthetic assumption", "Contractor C's inventory activity as one lane."],
    ["L3", "Local distribution, Riyadh region", "Riyadh facility", "Riyadh region", "road", "Palletised general goods",
     1000, 95, "2025", "OF-A-L3", "New synthetic assumption", "Remainder of Contractor A's inventory activity."],
    ["L4", "Lane served by Carrier B (details not received)", "Riyadh facility", None, "road", None, None, None, "2025",
     "OF-B-L4", "Missing data", "Destination, cargo, capacity and activity unknown."],
]
put_rows(ws_l, 5, rows, class_col=11, input_cols=range(1, 13))
dropdown(ws_l, "E5:E60", ["road", "rail", "sea", "air", "multimodal"])
dropdown(ws_l, "K5:K60", CLASSES)

# 3 Freight Activity ------------------------------------------------------------------------
ws = wb.create_sheet("Freight Activity")
title(ws, "Freight activity per supplier offer (tonne-km = freight mass x average distance)",
      "Incumbent offers reproduce the inventory activity by lane; alternative offers are synthetic tender data.")
cols = ["offer_id", "supplier_id", "lane_id", "role", "freight_mass_t", "avg_distance_km", "tonne_km", "reporting_period",
        "period_months", "offered_capacity_t_per_year", "cargo_types", "service_origin", "service_destination",
        "activity_source", "data_class"]
header(ws, 4, cols, [12, 13, 8, 12, 14, 14, 14, 12, 11, 16, 26, 18, 20, 44, 24])
rows = [
    ["OF-A-L1", "SUP-CARR-A", "L1", "Incumbent", 2500, 400, "=IF(AND(ISNUMBER(E5),ISNUMBER(F5)),E5*F5,\"\")", "2025", 12, 3000,
     "Palletised general goods", "Riyadh facility", "Dammam port area",
     "Carrier statements (Phase 4 records); lane split synthetic", "Existing synthetic baseline"],
    ["OF-A-L3", "SUP-CARR-A", "L3", "Incumbent", 1000, 200, "=IF(AND(ISNUMBER(E6),ISNUMBER(F6)),E6*F6,\"\")", "2025", 12, 1500,
     "Palletised general goods", "Riyadh facility", "Riyadh region",
     "Carrier statements (Phase 4 records); lane split synthetic", "Existing synthetic baseline"],
    ["OF-C-L2", "SUP-CARR-C", "L2", "Incumbent", 700, 1000, "=IF(AND(ISNUMBER(E7),ISNUMBER(F7)),E7*F7,\"\")", "2025", 12, 900,
     "Palletised general goods", "Riyadh facility", "Jeddah", "Carrier statements (Phase 4 records)", "Existing synthetic baseline"],
    ["OF-B-L4", "SUP-CARR-B", "L4", "Incumbent", None, None, "=IF(AND(ISNUMBER(E8),ISNUMBER(F8)),E8*F8,\"\")", "2025", 12, None,
     None, "Riyadh facility", None, "No data received (Phase 4 request log)", "Missing data"],
    ["OF-D-L1", "ALT-D", "L1", "Alternative", 2500, 400, "=IF(AND(ISNUMBER(E9),ISNUMBER(F9)),E9*F9,\"\")", "2025", 12, 3200,
     "Palletised general goods", "Riyadh facility", "Dammam port area", "Tender response (hypothetical)", "New synthetic assumption"],
    ["OF-E-L1", "ALT-E", "L1", "Alternative", 2500, 400, "=IF(AND(ISNUMBER(E10),ISNUMBER(F10)),E10*F10,\"\")", "2025", 12, 2600,
     "Palletised general goods", "Riyadh facility", "Dammam port area", "Tender response (hypothetical)", "New synthetic assumption"],
]
put_rows(ws, 5, rows, class_col=15, input_cols=[1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14])
dropdown(ws, "D5:D60", ["Incumbent", "Alternative"])
dropdown(ws, "O5:O60", CLASSES)
decimal_rule(ws, "E5:F60", 0, 1e9, "Mass and distance must be non-negative numbers (leave blank if unknown).")
for k in range(6):
    ws.cell(row=5 + k, column=7).fill = PatternFill("solid", fgColor=CLASS_FILL["Calculated output"])

# 5 Emission Factors ------------------------------------------------------------------------
ws = wb.create_sheet("Emission Factors")
title(ws, "Supplier and lane emission factors (kgCO2e per tonne-km)",
      "A blank value with linked_factor_id uses the Phase 4 library value (read by the app; not copied).")
cols = ["ef_id", "offer_id", "value", "unit", "calculation_method", "boundary", "gas_coverage", "source", "reference_year",
        "verification_status", "linked_factor_id", "data_class"]
header(ws, 4, cols, [14, 11, 10, 18, 26, 16, 12, 44, 12, 24, 18, 24])
rows = [
    ["P11-EF-A-L1", "OF-A-L1", 0.12, "kgCO2e/tonne-km", "Fuel-based (supplier fuel records)", "Tank-to-wheel", "CO2e",
     "Carrier A 2025 lane emissions statement (synthetic)", "2025", "Unverified - documented", None, "New synthetic assumption"],
    ["P11-EF-A-L3", "OF-A-L3", None, "kgCO2e/tonne-km", "Distance-based (proxy factor)", "Tank-to-wheel", "CO2e",
     "Phase 4 emission-factor library (DESNZ 2025 HGV average laden, UK proxy)", "2025", "Proxy", "FAC-FRT-ROAD-01",
     "Existing synthetic baseline"],
    ["P11-EF-C-L2", "OF-C-L2", None, "kgCO2e/tonne-km", "Distance-based (proxy factor)", "Tank-to-wheel", "CO2e",
     "Phase 4 emission-factor library (DESNZ 2025 HGV average laden, UK proxy)", "2025", "Proxy", "FAC-FRT-ROAD-01",
     "Existing synthetic baseline"],
    ["P11-EF-B-L4", "OF-B-L4", None, None, None, None, None, "Not received", None, "Missing", None, "Missing data"],
    ["P11-EF-D-L1", "OF-D-L1", 0.08, "kgCO2e/tonne-km", "Fuel-based (tender declaration)", "Tank-to-wheel", "CO2e",
     "Carrier D tender response (hypothetical)", "2025", "Unverified - claimed", None, "New synthetic assumption"],
    ["P11-EF-E-L1", "OF-E-L1", 0.07, "kgCO2e/tonne-km", "Fuel-based (tender declaration)", "Tank-to-wheel", "CO2e",
     "Carrier E tender response (hypothetical)", "2025", "Unverified - claimed", None, "New synthetic assumption"],
]
put_rows(ws, 5, rows, class_col=12, input_cols=range(1, 12))
dropdown(ws, "D5:D60", ["kgCO2e/tonne-km", "gCO2e/tonne-km"])
dropdown(ws, "E5:E60", ["Fuel-based (supplier fuel records)", "Fuel-based (tender declaration)", "Distance-based (proxy factor)",
                        "Distance-based (supplier-specific)", "Spend-based"])
dropdown(ws, "F5:F60", ["Tank-to-wheel", "Well-to-wheel"])
dropdown(ws, "J5:J60", ["Verified - third party", "Unverified - documented", "Unverified - claimed", "Proxy", "Missing"])
dropdown(ws, "L5:L60", CLASSES)
decimal_rule(ws, "C5:C60", 0, 10, "Emission factor must be a non-negative number in the stated unit.")

# 6 Financial Inputs ------------------------------------------------------------------------
ws = wb.create_sheet("Financial Inputs")
title(ws, "Financial and reliability inputs per offer (SAR, constant real prices) and global settings",
      "Annual service cost covers the offer's tonne-km; costs are assumed proportional to tonne-km when demand varies.")
cols = ["offer_id", "annual_service_cost_sar", "additional_recurring_cost_sar", "one_time_switching_cost_sar",
        "one_time_onboarding_monitoring_sar", "contract_exit_cost_sar", "on_time_delivery_pct", "cost_source", "data_class"]
header(ws, 4, cols, [11, 18, 18, 18, 20, 16, 14, 40, 24])
rows = [
    ["OF-A-L1", 300000, 0, 0, 0, 0, 95, "Current contract (synthetic)", "New synthetic assumption"],
    ["OF-A-L3", 70000, 0, 0, 0, 0, 95, "Current contract (synthetic)", "New synthetic assumption"],
    ["OF-C-L2", 190000, 0, 0, 0, 0, 92, "Current contract (synthetic)", "New synthetic assumption"],
    ["OF-B-L4", None, None, None, None, None, None, "Not received", "Missing data"],
    ["OF-D-L1", 320000, 0, 30000, 0, 0, 97, "Tender response (hypothetical)", "New synthetic assumption"],
    ["OF-E-L1", 290000, 0, 25000, 0, 0, 98, "Tender response (hypothetical)", "New synthetic assumption"],
]
put_rows(ws, 5, rows, class_col=9, input_cols=range(1, 9))
dropdown(ws, "I5:I30", CLASSES)
decimal_rule(ws, "B5:F30", 0, 1e10, "Costs must be non-negative SAR amounts (leave blank if unknown).")
decimal_rule(ws, "G5:G30", 0, 100, "On-time delivery is a percentage between 0 and 100.")
ws["A13"] = "GLOBAL SETTINGS"
ws["A13"].font = Font(name=FONT, bold=True, color=NAVY)
header(ws, 14, ["parameter", "value", "unit", "source / rule", "data_class"])
ws.freeze_panes = "A5"
g = [
    ["discount_rate", 0.05, "real, per year", "Phase 9 'Assumptions'!B19 (illustrative 5% real)", "Existing synthetic baseline"],
    ["horizon_years", 10, "years", "Phase 9 'Assumptions'!B18", "Existing synthetic baseline"],
    ["implementation_delay_years", 0, "years", "Benefits and cost differences start after the delay", "New synthetic assumption"],
    ["substitution_share", 1.0, "fraction of lane tonne-km", "1.0 = full lane; 0-1 = partial substitution", "New synthetic assumption"],
    ["willingness_to_pay_sar_per_t", None, "SAR per tCO2e", "Management carbon budget; blank = NOT SET (no automatic switch)", "Missing data"],
    ["verification_mandatory", "FALSE", "TRUE/FALSE", "Organisational policy: TRUE makes verification a screening requirement", "Project-designed rule"],
    ["cost_scales_with_demand", "TRUE", "TRUE/FALSE", "Contract cost proportional to tonne-km in demand sensitivity", "Project-designed rule"],
]
put_rows(ws, 15, g, class_col=5, input_cols=[2])
dropdown(ws, "B20:B21", ["TRUE", "FALSE"])

# 7 Screening Evidence ----------------------------------------------------------------------
ws = wb.create_sheet("Screening Evidence")
title(ws, "Supplier screening checklist (14 checks per offer)",
      "Gate = blocks selection if Fail; Material = blank/Missing gives 'Insufficient evidence'; Enhancement = confidence. "
      "'Auto' checks are derived by the engine from the data.")
CHECKS = [
    (1, "Supplier identity and service description", "Gate"),
    (2, "Legal and transportation safety requirements", "Gate"),
    (3, "Required transport capacity", "Auto"),
    (4, "Comparable routes and freight specifications", "Auto"),
    (5, "Freight mass and distance", "Auto"),
    (6, "Reporting period", "Auto"),
    (7, "Calculation methodology (fuel- or distance-based)", "Auto"),
    (8, "Emission-factor source and units", "Auto"),
    (9, "Accounting boundaries", "Auto"),
    (10, "Contract price and relevant cost information", "Auto"),
    (11, "Supporting evidence", "Material"),
    (12, "Third-party verification", "Enhancement"),
    (13, "Historical data completeness", "Enhancement"),
    (14, "Willingness to improve disclosure", "Enhancement"),
]
manual = {
    "OF-A-L1": {1: "Pass", 2: "Pass", 11: "Pass", 12: "Missing", 13: "Pass", 14: "Pass"},
    "OF-A-L3": {1: "Pass", 2: "Pass", 11: "Pass", 12: "Missing", 13: "Pass", 14: "Pass"},
    "OF-C-L2": {1: "Pass", 2: "Pass", 11: "Pass", 12: "Missing", 13: "Pass", 14: "Pass"},
    "OF-B-L4": {1: "Pass", 2: "Pass", 11: "Missing", 12: "Missing", 13: "Fail", 14: "Missing"},
    "OF-D-L1": {1: "Pass", 2: "Pass", 11: "Pass", 12: "Missing", 13: "Missing", 14: "Pass"},
    "OF-E-L1": {1: "Pass", 2: "Fail", 11: "Pass", 12: "Missing", 13: "Missing", 14: "Pass"},
}
evid = {
    "OF-A-L1": {11: "Monthly carrier statements 2025 (synthetic)", 2: "Transport licence and safety record on file (synthetic)"},
    "OF-D-L1": {2: "Licence and safety certificates in tender pack (hypothetical)", 11: "Tender declaration (hypothetical)"},
    "OF-E-L1": {2: "Transport operating licence not provided / expired (hypothetical)"},
    "OF-B-L4": {13: "0 of 12 months received"},
}
cols = ["offer_id", "supplier_id", "check_no", "check", "category", "status", "evidence_reference", "data_class"]
header(ws, 4, cols, [11, 13, 9, 46, 13, 11, 56, 24])
sup = {"OF-A-L1": "SUP-CARR-A", "OF-A-L3": "SUP-CARR-A", "OF-C-L2": "SUP-CARR-C", "OF-B-L4": "SUP-CARR-B",
       "OF-D-L1": "ALT-D", "OF-E-L1": "ALT-E"}
rows = []
for off in manual:
    for no, chk, cat in CHECKS:
        st = manual[off].get(no, "Auto")
        rows.append([off, sup[off], no, chk, cat, st, evid.get(off, {}).get(no),
                     "Missing data" if st == "Missing" else ("Calculated output" if st == "Auto" else "New synthetic assumption")])
put_rows(ws, 5, rows, class_col=8, input_cols=[6, 7])
dropdown(ws, "F5:F400", ["Pass", "Fail", "Missing", "N/A", "Auto"], "Pass / Fail / Missing / N/A, or Auto for engine-derived checks")
dropdown(ws, "H5:H400", CLASSES)

# 8 Supplier Maturity -----------------------------------------------------------------------
ws = wb.create_sheet("Supplier Maturity")
title(ws, "Maturity indicators (0-4) and data-quality dimensions (High / Medium / Low / Missing)",
      "Blank maturity indicator = not assessed (missing). Maturity is classified only if >= the minimum number of indicators is assessed.")
mcols = ["measurement_practice", "data_completeness", "methodological_transparency", "improvement_targets",
         "reporting_capability", "verification_evidence", "engagement_responsiveness"]
dcols = ["dq_completeness", "dq_temporal", "dq_geographic", "dq_technological", "dq_methodological", "dq_evidence_provenance",
         "dq_verification"]
cols = ["supplier_id"] + mcols + dcols + ["assessment_source", "data_class"]
header(ws, 4, cols, [13] + [14] * 14 + [44, 24])
rows = [
    ["SUP-CARR-A", 2, 4, 2, 0, 1, 0, 2, "High", "High", "High", "Medium", "Medium", "Medium", "Low",
     "Supplier questionnaire 2025 (synthetic)", "New synthetic assumption"],
    ["SUP-CARR-B", None, 0, None, None, None, 0, 1, "Missing", "Missing", "Low", "Missing", "Missing", "Missing", "Missing",
     "No response to data request (synthetic)", "Missing data"],
    ["SUP-CARR-C", 3, 4, 3, 2, 3, 1, 3, "High", "Medium", "Low", "Low", "Medium", "Medium", "Low",
     "Supplier questionnaire 2025 (synthetic)", "New synthetic assumption"],
    ["ALT-D", 3, 1, 3, 3, 2, 0, 3, "Low", "Medium", "Medium", "Medium", "Medium", "Low", "Low",
     "Tender questionnaire (hypothetical)", "New synthetic assumption"],
    ["ALT-E", 2, 1, 2, 2, 2, 0, 2, "Low", "Medium", "Medium", "Medium", "Medium", "Low", "Low",
     "Tender questionnaire (hypothetical)", "New synthetic assumption"],
]
put_rows(ws, 5, rows, class_col=17, input_cols=range(1, 17))
decimal_rule(ws, "B5:H60", 0, 4, "Maturity indicators are scored 0 (none) to 4 (advanced); leave blank if not assessed.")
dropdown(ws, "I5:O60", ["High", "Medium", "Low", "Missing"])
dropdown(ws, "Q5:Q60", CLASSES)
r0 = 12
ws.cell(row=r0, column=1, value="Indicator scale (project-designed)").font = Font(name=FONT, bold=True, color=NAVY)
scale = [["0", "No practice / no evidence"], ["1", "Ad hoc or informal"], ["2", "Defined but partial"],
         ["3", "Systematic, documented"], ["4", "Advanced, externally assured or target-driven"]]
put_rows(ws, r0 + 1, scale)

# 9 Engagement Matrix Rules -----------------------------------------------------------------
ws = wb.create_sheet("Engagement Matrix Rules")
title(ws, "Engagement priority matrix - PROJECT-DESIGNED thresholds and rules (editable)",
      "UN Global Compact framework segments suppliers by impact and maturity into Priorities 1-4 qualitatively; "
      "the numbers below are this project's assumptions.")
header(ws, 4, ["parameter", "value", "description", "data_class"], [34, 12, 90, 24])
params = [
    ["impact_threshold", 50, "Impact score >= threshold = HIGH impact (0-100 scale)", "Project-designed rule"],
    ["maturity_threshold", 50, "Maturity score >= threshold = HIGH maturity (0-100 scale)", "Project-designed rule"],
    ["impact_weight_emissions_share", 0.5, "Weight of the supplier's share of known freight emissions", "Project-designed rule"],
    ["impact_weight_volume_share", 0.3, "Weight of the supplier's share of known tonne-km", "Project-designed rule"],
    ["impact_weight_materiality", 0.2, "Weight of service materiality (Critical 100, Standard 50, Minor 0)", "Project-designed rule"],
    ["materiality_score_critical", 100, "Score for a critical service", "Project-designed rule"],
    ["materiality_score_standard", 50, "Score for a standard service", "Project-designed rule"],
    ["materiality_score_minor", 0, "Score for a minor service", "Project-designed rule"],
    ["min_maturity_indicators", 5, "Minimum assessed maturity indicators (of 7) needed to classify maturity", "Project-designed rule"],
]
put_rows(ws, 5, params, class_col=4, input_cols=[2])
header(ws, 16, ["quadrant", "impact", "maturity", "priority", "label", "recommended actions (separated by ;)"])
quad = [
    ["Q1", "High", "Low", 1, "Intensive engagement",
     "Improve emissions data collection; Establish reporting expectations; Provide calculation templates; "
     "Offer capacity building; Conduct targeted data-quality reviews; Agree on corrective actions"],
    ["Q2", "High", "High", 2, "Strategic collaboration",
     "Joint emissions-reduction projects; Route and load optimization; Fuel-efficiency improvements; "
     "More detailed supplier-specific data; Shared decarbonization targets; Verified improvement monitoring"],
    ["Q3", "Low", "Low", 3, "Basic development",
     "Provide standardized reporting templates; Offer introductory emissions guidance; Establish basic disclosure "
     "requirements; Monitor progress proportionately"],
    ["Q4", "Low", "High", 4, "Maintain and monitor",
     "Maintain supplier relationship; Continue periodic data reporting; Improve measurement detail where valuable; "
     "Monitor performance and new risks"],
    ["UNCLASSIFIED", "Unknown", "Unknown", "Data engagement", "Unclassified - insufficient evidence",
     "Request missing activity and evidence before classification (no quadrant is assigned)"],
]
put_rows(ws, 17, quad)

# 10 Scoring Weights ------------------------------------------------------------------------
ws = wb.create_sheet("Scoring Weights")
title(ws, "Supplier scoring model - DEFAULT PROJECT ASSUMPTIONS (not official UN percentages)",
      "Weights must be non-negative numbers; they are normalised to 100% before a total score is produced.")
header(ws, 4, ["criterion", "weight", "scoring method (0-100)", "benchmark_low", "benchmark_high", "unit", "data_class"],
       [30, 10, 80, 15, 15, 18, 24])
rows = [
    ["carbon_performance", 0.35, "100 x (benchmark_high - EF) / (benchmark_high - benchmark_low), clamped 0-100; "
     "EF in kgCO2e/t-km (intensity, not absolute emissions)", 0.05, 0.15, "kgCO2e/tonne-km", "Project-designed rule"],
    ["total_lifecycle_cost", 0.25, "50 + 50 x (incumbent annualised cost - offer annualised cost) / (band x incumbent), clamped; "
     "annualised cost = annual cost + recurring + one-time costs / annuity factor", None, 0.20, "band (fraction)",
     "Project-designed rule"],
    ["operational_reliability", 0.20, "100 x (on-time % - benchmark_low) / (benchmark_high - benchmark_low), clamped",
     90, 100, "% on-time", "Project-designed rule"],
    ["data_quality_transparency", 0.15, "Mean of 7 data-quality dimensions: High 100, Medium 60, Low 20, Missing 0",
     None, None, "score", "Project-designed rule"],
    ["improvement_capability", 0.05, "(improvement_targets + engagement_responsiveness) / 8 x 100", None, None, "score",
     "Project-designed rule"],
]
put_rows(ws, 5, rows, class_col=7, input_cols=[2, 4, 5])
ws["A11"] = "Total weight"; ws["B11"] = "=SUM(B5:B9)"
ws["A11"].font = Font(name=FONT, bold=True); ws["B11"].font = Font(name=FONT, bold=True)
ws["B11"].fill = PatternFill("solid", fgColor=CLASS_FILL["Calculated output"])
decimal_rule(ws, "B5:B9", 0, 100, "Weights must be non-negative numbers.")

# 11 Uncertainty Assumptions ----------------------------------------------------------------
ws = wb.create_sheet("Uncertainty Assumptions")
title(ws, "Low / base / high values for the lane L1 switching assessment (stress values, not probabilities)")
header(ws, 4, ["variable", "applies_to", "low", "base", "high", "unit", "favourable_to_switching", "note", "data_class"],
       [30, 12, 12, 12, 12, 18, 30, 60, 24])
rows = [
    ["alternative_ef", "OF-D-L1", 0.06, 0.08, 0.10, "kgCO2e/tonne-km", "lower", "Claimed tender factor; unverified", "New synthetic assumption"],
    ["current_ef", "OF-A-L1", 0.11, 0.12, 0.13, "kgCO2e/tonne-km", "higher", "Supplier statement unverified", "New synthetic assumption"],
    ["demand_tonne_km", "L1", 900000, 1000000, 1100000, "tonne-km/yr", "ambiguous (more tCO2e avoided and larger cost difference)",
     "Costs scale with tonne-km", "New synthetic assumption"],
    ["alternative_annual_cost", "OF-D-L1", 290000, 320000, 350000, "SAR/yr", "lower", "At base demand", "New synthetic assumption"],
    ["switching_cost", "OF-D-L1", 15000, 30000, 60000, "SAR one-time", "lower", "", "New synthetic assumption"],
    ["monitoring_cost", "OF-D-L1", 0, 0, 10000, "SAR/yr", "lower", "Additional recurring cost", "New synthetic assumption"],
    ["implementation_delay", "L1", 0, 0, 1, "years", "ambiguous (shifts both costs and avoided emissions later)",
     "", "New synthetic assumption"],
    ["alternative_on_time", "OF-D-L1", 95, 97, 98, "% on-time", "higher", "Affects score, not NPV", "New synthetic assumption"],
]
put_rows(ws, 5, rows, class_col=9, input_cols=[3, 4, 5])

# 12 Engagement Action Plans ----------------------------------------------------------------
ws = wb.create_sheet("Engagement Action Plans")
title(ws, "Action templates - deadlines are EDITABLE MANAGEMENT ASSUMPTIONS (days after plan start), not UN requirements")
header(ws, 4, ["trigger", "action", "responsible_role", "deadline_days", "required_evidence", "success_indicator",
               "verification_method", "data_class"], [18, 46, 26, 12, 44, 40, 34, 24])
T = "Project-designed rule"
rows = [
    ["Q1", "Improve emissions data collection", "Procurement category manager", 30, "Monthly fuel and tonne-km records",
     "12/12 months with fuel-based data", "Desk review of records", T],
    ["Q1", "Establish reporting expectations", "Procurement category manager", 30, "Signed data-reporting clause",
     "Clause in contract", "Contract register check", T],
    ["Q1", "Provide calculation templates", "Sustainability analyst", 30, "Completed template", "Template returned complete",
     "Template validation (DQ rules)", T],
    ["Q1", "Offer capacity building", "Sustainability analyst", 60, "Training attendance record", "Training completed",
     "Attendance record", T],
    ["Q1", "Conduct targeted data-quality reviews", "Sustainability analyst", 60, "Data-quality review report",
     "Data-quality score up by one level", "Re-run data-quality assessment", T],
    ["Q1", "Agree on corrective actions", "Procurement category manager", 90, "Corrective action plan",
     "Plan agreed and dated", "Follow-up meeting minutes", T],
    ["Q2", "Joint emissions-reduction projects", "Procurement lead + supplier", 90, "Project charter", "Charter signed",
     "Steering-group review", T],
    ["Q2", "Route and load optimization", "Logistics manager", 60, "Route and load plan", "Load factor improvement reported",
     "Telematics data review", T],
    ["Q2", "Fuel-efficiency improvements", "Logistics manager", 90, "Fuel-efficiency plan", "kgCO2e/t-km reduction reported",
     "Fuel records review", T],
    ["Q2", "More detailed supplier-specific data", "Sustainability analyst", 60, "Lane-level factors", "Lane factors provided",
     "Desk review", T],
    ["Q2", "Shared decarbonization targets", "Procurement lead", 90, "Target statement", "Target agreed", "Contract addendum", T],
    ["Q2", "Verified improvement monitoring", "Sustainability analyst", 90, "Assurance scope", "Assurance engaged",
     "Third-party assurance letter", T],
    ["Q3", "Provide standardized reporting templates", "Sustainability analyst", 30, "Template", "Template returned",
     "Desk review", T],
    ["Q3", "Offer introductory emissions guidance", "Sustainability analyst", 60, "Guidance note", "Guidance acknowledged",
     "Email confirmation", T],
    ["Q3", "Establish basic disclosure requirements", "Procurement category manager", 60, "Disclosure clause",
     "Clause agreed", "Contract register check", T],
    ["Q3", "Monitor progress proportionately", "Sustainability analyst", 90, "Annual data return", "Annual return received",
     "Desk review", T],
    ["Q4", "Maintain supplier relationship", "Procurement category manager", 90, "Review meeting note", "Review held",
     "Meeting minutes", T],
    ["Q4", "Continue periodic data reporting", "Sustainability analyst", 90, "Quarterly data return",
     "Returns on time", "Reporting log", T],
    ["Q4", "Improve measurement detail where valuable", "Sustainability analyst", 90, "Fuel-based lane data",
     "Proxy factor replaced", "Desk review", T],
    ["Q4", "Monitor performance and new risks", "Procurement category manager", 90, "Scorecard", "Scorecard updated",
     "Scorecard review", T],
    ["UNCLASSIFIED", "Request missing 12-month freight activity", "Procurement category manager", 30,
     "Monthly activity for 2025 (12 records)", "12/12 months received", "Phase 4 validator run (DQ-01 cleared)", T],
    ["UNCLASSIFIED", "Request freight mass and distance by shipment or month", "Logistics manager", 30,
     "Shipment mass (t) and distance (km)", "Tonne-km calculable", "Desk review", T],
    ["UNCLASSIFIED", "Request calculation methodology", "Sustainability analyst", 60, "Method statement (fuel or distance based)",
     "Method documented", "Desk review", T],
    ["UNCLASSIFIED", "Request emission-factor evidence", "Sustainability analyst", 60, "Factor source, unit and boundary",
     "Factor documented", "Desk review against Phase 4 rules", T],
    ["UNCLASSIFIED", "Request comparable financial and service information", "Procurement category manager", 90,
     "Annual cost, capacity, on-time %", "Comparable offer available", "Desk review", T],
    ["VERIFICATION_GAP", "Request third-party verification or assurance plan", "Sustainability analyst", 90,
     "Assurance scope or letter", "Assurance plan agreed", "Assurance letter", T],
    ["ALTERNATIVE_EVIDENCE", "Verify the alternative's claimed emission factor before any contract decision",
     "Sustainability analyst", 60, "Fuel records or assured factor", "Factor confirmed or revised", "Independent review", T],
    ["INELIGIBLE", "Escalate failed legal or safety gate to procurement and HSE", "Procurement lead", 30,
     "Licence and safety documentation", "Gate resolved or supplier excluded", "Compliance review", T],
]
put_rows(ws, 5, rows, class_col=8, input_cols=[4])
decimal_rule(ws, "D5:D100", 0, 3650, "Deadline in days after plan start.")

# 13 Monitoring Indicators ------------------------------------------------------------------
ws = wb.create_sheet("Monitoring Indicators")
title(ws, "Supplier monitoring scorecard indicators (current values synthetic; 'n/a' = not yet observable)")
header(ws, 4, ["indicator", "definition", "unit", "source", "SUP-CARR-A", "SUP-CARR-B", "SUP-CARR-C", "data_class"],
       [32, 60, 14, 34, 12, 12, 12, 24])
rows = [
    ["reporting_timeliness_days", "Average days late for monthly data returns", "days", "Reporting log (synthetic)", 5, None, 0,
     "New synthetic assumption"],
    ["baseline_maturity_score", "Maturity score at the start of engagement (engine result)", "0-100", "Supplier Maturity sheet",
     None, None, None, "Calculated output"],
    ["prior_period_intensity", "Carbon intensity in the previous reporting period", "kgCO2e/t-km", "Not available (first year)",
     None, None, None, "Missing data"],
    ["prior_period_tonne_km", "Transport activity in the previous reporting period", "tonne-km", "Not available (first year)",
     None, None, None, "Missing data"],
    ["verified_actual_reduction", "Reduction confirmed after implementation", "tCO2e", "None - no post-implementation data",
     None, None, None, "Missing data"],
]
put_rows(ws, 5, rows, class_col=8, input_cols=[5, 6, 7])

# 14 Source Register ------------------------------------------------------------------------
ws = wb.create_sheet("Source Register")
title(ws, "Source register (accessed 2026-10-23)")
header(ws, 4, ["id", "title", "publisher", "url", "how used", "what it does NOT establish", "access status", "data_class"],
       [6, 46, 26, 60, 46, 46, 30, 14])
rows = [
    ["S1", "Sustainable Procurement Implementation Framework", "UN Global Compact", "https://procurementframework.unglobalcompact.org/",
     "Procurement cycle (strategy, selection, engagement, continuous improvement); impact x maturity segmentation into Priorities 1-4",
     "Numeric weights, thresholds or scores (the framework states it is not a scoring tool)", "Page opened 2026-10-23", "Reference"],
    ["S2", "GHG Emissions Data Management", "UN Global Compact",
     "https://procurementframework.unglobalcompact.org/framework/ghg-emissions-data-management",
     "Data requests, data-quality progression, verification, scorecards", "Project thresholds or deadlines",
     "Page opened 2026-10-23", "Reference"],
    ["S3", "GHG Emissions Reduction", "UN Global Compact",
     "https://procurementframework.unglobalcompact.org/framework/ghg-emissions-reduction",
     "Selection criteria, capacity building, audits, corrective action plans, scorecards", "Switching rules or carbon prices",
     "Page opened 2026-10-23", "Reference"],
    ["S4", "Corporate Value Chain (Scope 3) Accounting and Reporting Standard (2011)", "GHG Protocol",
     "https://ghgprotocol.org/standards/scope-3-standard", "Scope 3 boundary; Category 4 classification",
     "Supplier selection decisions", "Landing page opened 2026-10-23", "Reference"],
    ["S5", "Technical Guidance for Calculating Scope 3 Emissions", "GHG Protocol",
     "https://ghgprotocol.org/scope-3-calculation-guidance-2",
     "Category 4 fuel-, distance- and spend-based methods (as cited in Phase 3 from the supplied PDF, pp. 49-61)",
     "Supplier-specific factors used here", "Landing page opened; method chapter cited via Phase 3", "Reference"],
    ["S6", "Phase 4 emission-factor library (FAC-FRT-ROAD-01)", "Project (DESNZ 2025 UK proxy)", "phase4/data/emission_factors.csv",
     "Proxy factor for lanes without supplier-specific data", "Saudi supplier-specific performance", "In package", "Reference"],
    ["S7", "Phase 9 workbook (discount rate, horizon)", "Project", "workbooks/Phase9_Financial_Operational_Evaluation.xlsx",
     "5% real rate, 10-year horizon", "A Saudi corporate hurdle rate", "In package", "Reference"],
]
put_rows(ws, 5, rows, class_col=8)

# 15 Validation Cases -----------------------------------------------------------------------
ws = wb.create_sheet("Validation Cases")
title(ws, "Validation cases - independent spreadsheet calculation of the synthetic demonstration (lane L1: A vs D)",
      "Inputs in blue; results are Excel formulas. The 'brief target' column records values stated in the Phase 11 brief.")
header(ws, 4, ["item", "value", "unit", "formula / note", "brief target", "difference vs target"], [44, 16, 14, 70, 14, 16])
v = [
    ["Current tonne-km (A)", 1000000, "t-km", "Input"],
    ["Current emission factor (A)", 0.12, "kgCO2e/t-km", "Input"],
    ["Alternative tonne-km (D)", 1000000, "t-km", "Input (equivalent service)"],
    ["Alternative emission factor (D)", 0.08, "kgCO2e/t-km", "Input"],
    ["Current annual cost (A)", 300000, "SAR/yr", "Input"],
    ["Alternative annual cost (D)", 320000, "SAR/yr", "Input"],
    ["Additional recurring cost", 0, "SAR/yr", "Input"],
    ["One-time switching cost", 30000, "SAR", "Input"],
    ["Discount rate (real)", 0.05, "per year", "Input"],
    ["Horizon", 10, "years", "Input"],
    ["Current emissions", "=B5*B6/1000", "tCO2e/yr", "tonne-km x EF / 1000", 120],
    ["Alternative emissions", "=B7*B8/1000", "tCO2e/yr", "tonne-km x EF / 1000", 80],
    ["Avoided emissions", "=B15-B16", "tCO2e/yr", "current - alternative", 40],
    ["Percentage reduction", "=IF(B15>0,B17/B15,\"\")", "fraction", "avoided / current", 0.3333333333],
    ["Annual cost difference (alternative - current)", "=B10-B9+B11", "SAR/yr", "positive = additional cost", 20000],
    ["Incremental annual cost per tonne avoided", "=IF(B17>0,B19/B17,\"\")", "SAR/tCO2e", "excludes switching cost", 500],
    ["Annuity factor", "=(1-(1+B13)^-B14)/B13", "", "PV of SAR 1 per year, years 1..n"],
    ["Switching NPV (closed form)", "=-B12+(B9-B10-B11)*B21", "SAR", "-switching cost + PV(net savings)", -184443],
    ["Switching NPV (Excel PV function)", "=-B12+PV(B13,B14,-(B9-B10-B11))", "SAR", "cross-check", -184443],
    ["Break-even alternative annual cost", "=B9-B11-B12/B21", "SAR/yr", "NPV = 0", 296115],
    ["Discounted lifetime cost per tonne", "=IF(B17>0,-B22/(B17*B21),\"\")", "SAR/tCO2e",
     "NPC / discounted tonnes (both discounted over the same horizon)"],
    ["Carbon break-even alternative EF", "=B6*B5/B7", "kgCO2e/t-km", "EF at which avoided emissions = 0"],
]
put_rows(ws, 5, v, input_cols=[2])
for rr in range(15, 27):
    if ws.cell(row=rr, column=5).value is not None:
        ws.cell(row=rr, column=6, value=f"=IF(ISNUMBER(E{rr}),B{rr}-E{rr},\"\")")
    ws.cell(row=rr, column=2).fill = PatternFill("solid", fgColor=CLASS_FILL["Calculated output"])
ws["B18"].number_format = "0.00%"
ws["A28"] = ("Note: the brief's switching-NPV target (approx. -184,443) differs from the formula result by about SAR 8; "
             "the annuity factor for 5% over 10 years is 7.72173, giving -184,434.70. The break-even (296,115) and other targets agree.")
ws["A28"].font = Font(name=FONT, italic=True, size=9, color="C00000")
ws["A30"] = "Partial substitution case (40% of lane L1 switched to D)"
ws["A30"].font = Font(name=FONT, bold=True, color=NAVY)
pv = [
    ["Substitution share", 0.4, "fraction", "Input"],
    ["Switched tonne-km", "=B5*B31", "t-km", "share x lane tonne-km"],
    ["Avoided emissions (partial)", "=B32*(B6-B8)/1000", "tCO2e/yr", "switched t-km x (EF current - EF alternative) / 1000"],
    ["Annual cost difference (partial)", "=B31*(B10-B9)+B11", "SAR/yr", "share x cost difference + recurring"],
    ["Switching NPV (partial, same one-time cost)", "=-B12-B34*B21", "SAR", "one-time cost not scaled"],
]
put_rows(ws, 31, pv, input_cols=[2])

wb.move_sheet("Service Equivalence", offset=wb.sheetnames.index("Financial Inputs") - wb.sheetnames.index("Service Equivalence"))
order = ["README", "Supplier Profiles", "Freight Activity", "Emission Factors", "Service Equivalence", "Financial Inputs",
         "Screening Evidence", "Supplier Maturity", "Engagement Matrix Rules", "Scoring Weights", "Uncertainty Assumptions",
         "Engagement Action Plans", "Monitoring Indicators", "Source Register", "Validation Cases"]
wb._sheets = [wb[n] for n in order]
for s in wb.worksheets:
    s.sheet_view.zoomScale = 90
wb.save(OUT)
print("written", OUT)
